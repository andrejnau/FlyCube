#!/bin/bash

./test_shaders.sh --update

