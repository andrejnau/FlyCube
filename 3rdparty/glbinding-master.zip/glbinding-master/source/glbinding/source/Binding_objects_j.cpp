
#include "Binding_pch.h"

using namespace gl; // ToDo: multiple APIs?


namespace glbinding 
{





} // namespace glbinding
