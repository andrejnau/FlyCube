
// on gcc, this file is used since compilation of single file is fast
// for msvc, in contrast, this file is not added to the project, since /bigobj would be required

#include <glbinding/gl/functions.h>

#include "functions_a.cpp"
#include "functions_b.cpp"
#include "functions_c.cpp"
#include "functions_d.cpp"
#include "functions_e.cpp"
#include "functions_f.cpp"
#include "functions_g.cpp"
#include "functions_h.cpp"
#include "functions_i.cpp"
#include "functions_j.cpp"
#include "functions_k.cpp"
#include "functions_l.cpp"
#include "functions_m.cpp"
#include "functions_n.cpp"
#include "functions_o.cpp"
#include "functions_p.cpp"
#include "functions_q.cpp"
#include "functions_r.cpp"
#include "functions_s.cpp"
#include "functions_t.cpp"
#include "functions_u.cpp"
#include "functions_v.cpp"
#include "functions_w.cpp"
#include "functions_x.cpp"
#include "functions_y.cpp"
#include "functions_z.cpp"
