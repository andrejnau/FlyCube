
#pragma once

namespace 
{
    const unsigned int GL_REVISION = 32348;
}
