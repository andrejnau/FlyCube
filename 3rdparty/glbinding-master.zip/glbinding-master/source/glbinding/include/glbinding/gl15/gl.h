
#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl15/types.h>
#include <glbinding/gl15ext/types.h>
#include <glbinding/gl15/boolean.h>
#include <glbinding/gl15ext/boolean.h>
#include <glbinding/gl15/values.h>
#include <glbinding/gl15ext/values.h>
#include <glbinding/gl15/bitfield.h>
#include <glbinding/gl15ext/bitfield.h>
#include <glbinding/gl15/enum.h>
#include <glbinding/gl15ext/enum.h>
#include <glbinding/gl15/functions.h>
#include <glbinding/gl15ext/functions.h>
