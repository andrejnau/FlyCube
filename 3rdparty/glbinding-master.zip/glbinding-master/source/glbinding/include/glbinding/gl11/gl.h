
#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl11/types.h>
#include <glbinding/gl11ext/types.h>
#include <glbinding/gl11/boolean.h>
#include <glbinding/gl11ext/boolean.h>
#include <glbinding/gl11/values.h>
#include <glbinding/gl11ext/values.h>
#include <glbinding/gl11/bitfield.h>
#include <glbinding/gl11ext/bitfield.h>
#include <glbinding/gl11/enum.h>
#include <glbinding/gl11ext/enum.h>
#include <glbinding/gl11/functions.h>
#include <glbinding/gl11ext/functions.h>
