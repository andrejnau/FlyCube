
#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl42ext/types.h>
#include <glbinding/gl42ext/boolean.h>
#include <glbinding/gl42ext/values.h>
#include <glbinding/gl42ext/bitfield.h>
#include <glbinding/gl42ext/enum.h>
#include <glbinding/gl42ext/functions.h>
