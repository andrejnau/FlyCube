#pragma once

#include "glLoadGen/gl_core_4_5.h"
