#pragma once

namespace glbinding
{


const unsigned int GL_REVISION = 32957; ///< The revision of the gl.xml at the time of code generation.


} // namespace glbinding
