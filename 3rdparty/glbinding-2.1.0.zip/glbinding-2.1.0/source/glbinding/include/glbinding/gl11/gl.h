#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl11/types.h>
#include <glbinding/gl11/boolean.h>
#include <glbinding/gl11/values.h>
#include <glbinding/gl11/bitfield.h>
#include <glbinding/gl11/enum.h>
#include <glbinding/gl11/functions.h>
