#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl44core/types.h>
#include <glbinding/gl44core/boolean.h>
#include <glbinding/gl44core/values.h>
#include <glbinding/gl44core/bitfield.h>
#include <glbinding/gl44core/enum.h>
#include <glbinding/gl44core/functions.h>
