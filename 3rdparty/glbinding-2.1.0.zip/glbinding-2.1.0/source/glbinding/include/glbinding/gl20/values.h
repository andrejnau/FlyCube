#pragma once

#include <glbinding/nogl.h>
#include <glbinding/gl/values.h>


namespace gl20
{





} // namespace gl20
