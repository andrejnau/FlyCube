#include "foo.h"
float4 i5;
