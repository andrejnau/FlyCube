        u = g_nDataIdx;
